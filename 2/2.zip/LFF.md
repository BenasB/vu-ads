### LFF

| Date       | From  | To    | Disturbances | Time  | Activity      | Comments                                                                    |
| ---------- | ----- | ----- | ------------ | ----- | ------------- | --------------------------------------------------------------------------- |
| 2022-04-03 | 13:00 | 15:49 |              | 02:49 | Programming   | Added bruteforce implementation                                             |
| 2022-04-03 | 23:00 | 23:15 |              | 00:15 | Programming   | Attack map generation                                                       |
| 2022-04-04 | 22:30 | 22:58 |              | 00:28 | Programming   | Changed knight move combination to for loops and getLowestAttackabilityTile |
| 2022-04-05 | 16:50 | 17:52 |              | 01:02 | Programming   | Implemented backtracking with recursion, solutions found                    |
| 2022-04-05 | 17:52 | 18:11 |              | 00:18 | Documentation | Determined bruteforce time complexity and combinations                      |
| 2022-04-05 | 18:11 | 19:52 |              | 01:40 | Documentation | Failed to determine backtracking time complexity                            |
| 2022-04-05 | 19:52 | 20:08 |              | 00:16 | Programming   | Added timer                                                                 |